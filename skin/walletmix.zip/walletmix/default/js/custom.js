jQuery(document).ready(function() {
     
	jQuery("#feed_submit").click(function(){
		var name = jQuery("#feed_name").val();
		var email = jQuery("#feed_email").val();
		var comment = jQuery("#feed_comment").val();
		
		jQuery("#feed_reply").html("<i>Please wait...</i>");
		
		jQuery.post('http://shopndsmile.com/send_email.php' , { name:name, email:email, comment:comment }, function(data){
			jQuery("#feed_reply").html(data);
		});
		return false;
	});
	
	jQuery(".owl-carousel").owlCarousel({
		items:5,
		lazyLoad:true,
		autoPlay : true
	});
	
	jQuery(".skip-active").click(function(){
		jQuery('.header-minicart .block-cart').css('display','block');
	});
	
	jQuery(".close").click(function(){
		jQuery('.header-minicart .block-cart').css('display','none');
	});
	
	jQuery("#like-button-fb").mouseenter(function(){
		jQuery('#like-button-fb').css('margin-right','0px');
	});
	
	jQuery("#like-button-fb").mouseleave(function(){
		jQuery('#like-button-fb').css('margin-right','-342px');
	});
	
	jQuery("#feed_img").mouseenter(function(){
		jQuery('#custom_feedback').css('margin-right','0px');
	});
	
	jQuery("#custom_feedback").mouseleave(function(){
		jQuery('#custom_feedback').css('margin-right','-397px');
	});
	
	
	jQuery(".custom-select").each(function(){
		jQuery(this).wrap("<span class='select-wrapper'></span>");
		jQuery(this).after("<span class='holder'></span>");
	});
	jQuery(".custom-select").change(function(){
		var selectedOption = jQuery(this).find(":selected").text();
		jQuery(this).next(".holder").text(selectedOption);
	});

});